# Move:
W A S D - Forward, Left, Back, Right

Q R - Tilt Up, Down

G - God Rays Toggle